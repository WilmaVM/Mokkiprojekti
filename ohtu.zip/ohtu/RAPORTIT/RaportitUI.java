package projekti.ohtu.RAPORTIT;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import projekti.ohtu.Tietokanta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Tämä luokka vastaa raporttien näyttämisestä käyttäöliittymällä.
 * Luokka hyödyntää tietokantayhteyttä raporttien muodostamiseksi.
 * Raportit esitetään visuaalisesti erilaisten kaavioiden avulla.
 */

public class RaportitUI {

        private static LineChart<String, Number> varausAjat;
        private static BarChart<String, Number> suosituinMokki;
        private static PieChart rahavirta;

        private static Label saatavat = new Label("Avoimet");
        private static Label saadut = new Label("Suoritukset");

    /**
     * Näyttää ikkunan, jonne raporttinäkymä avautuu.
     * Luo käyttöliittymälle komponentit ja sijoittelee ne kehykseen.
     */
    public static void nayta() {
        haeRaportti();

        // Paluu -painike
        Button paluu = new Button("Takaisin");
        paluu.setStyle("-fx-border-color: darkgreen;");
        paluu.setOnAction(e -> ((Stage) paluu.getScene().getWindow()).close());

        // SIJOITELLAAN KOMPONENTIT
        VBox oikeaAla = new VBox(10, varausAjat);
        oikeaAla.setStyle("-fx-background-color: transparent;");

        VBox vasenAla = new VBox(10, rahavirta);
        vasenAla.setStyle("-fx-background-color: transparent;");

        VBox asettelu1 = new VBox(suosituinMokki);
        asettelu1.setStyle("-fx-background-color: transparent;");
        asettelu1.setAlignment(Pos.CENTER);
        suosituinMokki.setPrefSize(1200, 500);

        HBox asettelu2 = new HBox(50, oikeaAla,vasenAla);
        asettelu2.setStyle("-fx-background-color: transparent;");
        asettelu2.setAlignment(Pos.CENTER);

        VBox asettelu3 = new VBox(20, asettelu1, asettelu2, paluu);
        asettelu3.setStyle("-fx-background-color: transparent;");
        asettelu3.setAlignment(Pos.CENTER);

        Stage nakyma = new Stage();
        nakyma.setTitle("Raportit");
        nakyma.setScene(new Scene(asettelu3, 900, 800));
        nakyma.show();
    }

    /**
     * Hakee raportteihin datan tietokannasta.
     * Tekee kaaviot niiden pohjalta
     * Kaaviotyyppeinä LineChart, BarChart ja PieChart
     */
    public static void haeRaportti() {
        try (Connection yhdista = Tietokanta.getConnection()) {

            // 1. Varausaikojen kehittymisen näyttämiseen (LineChart)
            NumberAxis n1 = new NumberAxis();
            CategoryAxis c1 = new CategoryAxis();
            c1.setLabel("Kuukausi");
            n1.setLabel("Päivät");

            varausAjat = new LineChart<>(c1, n1);
            varausAjat.setTitle("Keskimääräisen varausajan kehittyminen");

            XYChart.Series<String, Number> sarja = new XYChart.Series<>();
            sarja.setName("Keskim. varausaika / kk");

            PreparedStatement ps = yhdista.prepareStatement(
                    "SELECT MONTH(aloitus_pvm) AS kuukausi, " +
                            "AVG(DATEDIFF(paattymis_pvm, aloitus_pvm)) AS keskiarvo " +
                            "FROM varaus " +
                            "GROUP BY MONTH(aloitus_pvm) ORDER BY kuukausi"
            );
            ResultSet rs = ps.executeQuery();
            String[] kuukaudet = {
                    "", "Tammi", "Helmi", "Maalis", "Huhti", "Touko", "Kesä", "Heinä", "Elo", "Syys", "Loka", "Marras", "Joulu"
            };
            while (rs.next()) {
                int kk = rs.getInt("kuukausi");
                double keskiarvo = rs.getDouble("keskiarvo");
                sarja.getData().add(new XYChart.Data<>(kuukaudet[kk], keskiarvo));
            }
            varausAjat.getData().add(sarja);
            sarja.getNode().lookup(".chart-series-line").setStyle("-fx-stroke: #006400;");
            for (XYChart.Data<String, Number> data : sarja.getData()) {
                data.getNode().setStyle("-fx-background-color: #006400, white;");
            }

            // 2. Suosituimman mökin näyttämiseen (BarChart)
            CategoryAxis c2 = new CategoryAxis();
            NumberAxis n2 = new NumberAxis();
            c2.setLabel("Osoite");
            n2.setLabel("Varausten määrä");
            suosituinMokki = new BarChart<>(c2, n2);
            suosituinMokki.setTitle("Suosituimmat mökit");

            PreparedStatement ps2 = yhdista.prepareStatement(
                    "SELECT Mokit.osoite, COUNT(*) AS maara " +
                            "FROM varaus JOIN Mokit ON varaus.mokki_id = Mokit.mokki_id " +
                            "GROUP BY Mokit.osoite " +
                            "ORDER BY maara DESC LIMIT 5"
            );
            ResultSet rs2 = ps2.executeQuery();

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Top 5");

            while (rs2.next()) {
                String osoite = rs2.getString("osoite");
                int maara = rs2.getInt("maara");
                series.getData().add(new XYChart.Data<>(osoite, maara));
            }
            suosituinMokki.getData().clear();
            suosituinMokki.getData().add(series);

            for (XYChart.Data<String, Number> data : series.getData()) {
                data.getNode().setStyle("-fx-bar-fill: #006400;");
            }

            // 3. Saatavien ja saatujen näyttämiseen (PieChart)
            rahavirta = new PieChart();
            rahavirta.setTitle("Laskujen tila");
            rahavirta.setLabelsVisible(true);
            rahavirta.setLegendVisible(true);

            int saatavatLkm = 0;
            int saatavatSumma = 0;

            int saadutLkm = 0;
            int saadutSumma = 0;

            PreparedStatement ps3 = yhdista.prepareStatement(
                    "SELECT COUNT(*) AS maara, SUM(summa) AS summa FROM lasku WHERE maksupaiva IS NULL"
            );
            ResultSet rs3 = ps3.executeQuery();
            if (rs3.next()) {
                saatavatLkm = rs3.getInt("maara");
                saatavatSumma = rs3.getInt("summa");
                saatavat.setText("Avoimet laskut: " + saatavatLkm + " kpl, yhteensä " + saatavatSumma + " €");
            }

            PreparedStatement p4 = yhdista.prepareStatement(
                    "SELECT COUNT(*) AS maara, SUM(summa) AS summa FROM lasku WHERE maksupaiva IS NOT NULL"
            );
            ResultSet rs4 = p4.executeQuery();
            if (rs4.next()) {
                saadutLkm = rs4.getInt("maara");
                saadutSumma = rs4.getInt("summa");
                saadut.setText("Maksetut laskut: " + saadutLkm + " kpl, yhteensä " + saadutSumma + " €");
            }

            rahavirta.getData().clear();
            rahavirta.getData().addAll(
                    new PieChart.Data("Avoimet: " + saatavatSumma + " €", saatavatLkm),
                    new PieChart.Data("Maksetut: " + saadutSumma + " €", saadutLkm)
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
