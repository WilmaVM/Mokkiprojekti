package projekti.ohtu.MOKIT;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

/**
 * Tämä luokka mahdollistaa mökkien tietojen tarkastelemisen graafisessa käyttöliittymässä.
 * Luokka sisältää attribuuttien tiedot taulukon muodossa.
 */

public class MokkienHallinta {

    /**
     * Näyttää ikkunan, jonne mökkien hallinta -näkymä avautuu.
     */
    public static void nayta() {

        // Tehdään taulukko
        TableView<Mokit> taulukko1 = new TableView<>();
        taulukko1.setStyle("-fx-border-color: darkgreen;");
        taulukko1.setItems(getMokit());

        TableColumn<Mokit, String> ID = new TableColumn<>("ID");
        ID.setCellValueFactory(new PropertyValueFactory<>("mokinID"));

        TableColumn<Mokit, String> Osoite = new TableColumn<>("Osoite");
        Osoite.setCellValueFactory(new PropertyValueFactory<>("mokinOsoite"));

        TableColumn<Mokit, Double> Hinta = new TableColumn<>("Hinta (€/yö)");
        Hinta.setCellValueFactory(new PropertyValueFactory<>("mokinHinta"));

        TableColumn<Mokit, String> Varustelu = new TableColumn<>("Varustelu");
        Varustelu.setCellValueFactory(new PropertyValueFactory<>("mokinVarustelu"));

        TableColumn<Mokit, Integer> Kapasiteetti = new TableColumn<>("Kapasiteetti (hlö)");
        Kapasiteetti.setCellValueFactory(new PropertyValueFactory<>("mokinKapasiteetti"));

        taulukko1.getColumns().addAll(ID, Osoite, Kapasiteetti, Varustelu, Hinta);

        Label otsikko = new Label("MÖKIT");
        otsikko.setTextFill(Color.DARKGREEN);

        // Paluu -painike
        Button paluu = new Button("Takaisin");
        paluu.setOnAction(e -> ((Stage) paluu.getScene().getWindow()).close());
        paluu.setStyle("-fx-border-color: darkgreen;");

        // SIJOITELLAAN KOMPONENTIT
        VBox asettelu1 = new VBox(10, otsikko, taulukko1, paluu);
        asettelu1.setStyle("-fx-padding: 10; -fx-border-width: 3px; -fx-background-color: transparent; -fx-border-color: darkgreen;");

        Stage nakyma = new Stage();
        nakyma.setTitle("Mökkien hallinta");
        nakyma.setScene(new Scene(asettelu1, 800, 600));
        nakyma.show();
    }

    /**
     * Mökkien tiedot esitetty listauksena
     */
    private static final ObservableList<Mokit> mokit = FXCollections.observableArrayList(
                new Mokit("Kemppistie 21, 80110 Koli", 101, 590, "Suihku", 4),
                new Mokit("Ylisraitti 1017, 80330 Nurmes", 102, 620, "Suihku, Sauna", 4),
                new Mokit("Majavalammentie 382, 80120 Patvinsuo", 103, 700, "Suihku, Sauna", 6),
                new Mokit("Taivaltunnel 111, 80200 Tuusniemi", 104, 1200, "Suihku, Sauna, Poreamme", 10),
                new Mokit("Sammalpolku 6, 80220 Kesälahti", 105, 1000, "Suihku, Sauna, Poreamme", 8),
                new Mokit("Telekientie 66, 80310 Heinävaara", 106, 850, "Suihku, Sauna, Poreamme", 5));

    /**
     * Palauttaa listauksen mökkien tiedoista
     * @return lista mökeistä
     */
        public static ObservableList<Mokit> getMokit() {
            return mokit;
    }
}
