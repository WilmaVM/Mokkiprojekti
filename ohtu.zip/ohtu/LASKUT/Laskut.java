package projekti.ohtu.LASKUT;

/**
 * Tämä luokka sisältää laskujen perustiedot niiden käsittelemiseksi järjestelmässä.
 */

public class Laskut {

    // Oliomuuttujat
    private String eraPaiva;
    private int varausID;
    private int laskunID;
    private int summa;
    private String maksuPaiva;

    /**
     * Luodaan uusi Laskut -olio annetuilla tiedoilla
     * @param eraPaiva laskun eräpäivä
     * @param varausID varaustunnus, johon lasku liitetään
     * @param laskunID laskun yksilöintitieto
     * @param summa summa (euro)
     * @param maksuPaiva laskun suorituspäivä
     */
    Laskut(String eraPaiva, int varausID, int laskunID, int summa, String maksuPaiva) {
        this.eraPaiva = eraPaiva;
        this.varausID = varausID;
        this.laskunID = laskunID;
        this.summa = summa;
        this.maksuPaiva = maksuPaiva;
    }

    // Getterit ja Setterit

    /**
     * Palauttaa laskun eräpäivän
     * @return eräpäivä
     */
    public String getEraPaiva() {
        return eraPaiva;
    }

    /**
     * Palauttaa varaustunnuksen eli ID:n
     * @return varaus ID
     */
    public int getVarausID() {
        return varausID;
    }

    /**
     * Palauttaa laskun yksilöintitiedon eli ID:n
     * @return lasku ID
     */
    public int getLaskunID() {
        return laskunID;
    }

    /**
     * Palauttaa laskun summan
     * @return summa
     */
    public int getSumma() {
        return summa;
    }

    /**
     * Palauttaa laskun suorituspäivän
     * @return maksupäivä
     */
    public String getMaksuPaiva() {
        return maksuPaiva;
    }

    /**
     * Syöttää laskun suorituspäivän
     * @param maksuPaiva
     */
    public void setMaksuPaiva(String maksuPaiva) {
        this.maksuPaiva = maksuPaiva;
    }
}
