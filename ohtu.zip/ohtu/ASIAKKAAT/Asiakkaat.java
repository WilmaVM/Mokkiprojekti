package projekti.ohtu.ASIAKKAAT;

/**
 * Tämä luokka sisältää asiakkaan tiedot
 */
public class Asiakkaat {

    // Oliomuuttujat
    private String nimi;
    private String puhelinnumero;
    private String sahkoposti;
    private int asiakasID;

    /**
     * Luodaan uusi Asiakkaat -olio annetuilla tiedoilla
     * @param nimi asiakkaan nimi
     * @param puhelinnumero asiakkaan puhelinnumero
     * @param sahkoposti asiakkaan sähköpostiosoite
     * @param asiakasID asiakkaan ID-numero
     */
    public Asiakkaat(String nimi, String puhelinnumero, String sahkoposti, int asiakasID) {
        this.nimi = nimi;
        this.puhelinnumero = puhelinnumero;
        this.sahkoposti = sahkoposti;
        this.asiakasID = asiakasID;
    }

    /**
     * Palauttaa asiakkaan nimen
     * @return asiakkaan nimi
     */
    public String getNimi() {
        return nimi;

    }

    @Override
    public String toString() {
        return nimi;
    }

    /**
     * Palauttaa asiakkaan puhelinnumeron
     * @return asiakkaan puhelinnumero
     */
    public String getPuhelinnumero() {
        return puhelinnumero;
    }

    /**
     * Palauttaa asiakkaan sähköpostiosoitteen
     * @return asiakkaan sähköpostiosoite
     */
    public String getSahkoposti() {
        return sahkoposti;
    }

    /**
     * Palauttaa asiakkaan ID-numeron
     * @return asiakas ID
     */
    public int getAsiakasID() {
        return asiakasID;
    }
    }

