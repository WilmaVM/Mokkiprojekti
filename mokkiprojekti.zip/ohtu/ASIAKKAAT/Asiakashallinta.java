package projekti.ohtu.ASIAKKAAT;

import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import projekti.ohtu.Tietokanta;

import java.sql.*;

/**
 * Tämä luokka vastaa asiakkaiden näyttämisestä ja käsittelystä graafisessa käyttöliittymässä.
 * Luokka mahdollistaa asiakkaiden tarkastelun, lisäyksen ja poiston.
 * Luokka hyödyntää tietokantayhteyttä tietojen hallinnoimiseksi.
 */
public class Asiakashallinta {

    /**
     * Sisällytetään kaikki asiakkaat käyttöliittymän taulukko -näkymään
     */
    private static final ObservableList<Asiakkaat> asiakkaat = FXCollections.observableArrayList();

    /**
     * Näyttää ikkunan, jonne asiakashallinta -näkymä avautuu.
     * Luo käyttöliittymälle taulukon ja muut komponentit sekä sijoittaa ne kehykseen.
     */
    public static void nayta() {
        lueAsiakkaat();

        // Tehdään taulukko
        TableView<Asiakkaat> taulukko2 = new TableView<>();
        taulukko2.setStyle("-fx-border-color: darkgreen;");
        taulukko2.setItems(asiakkaat);
        taulukko2.setPrefWidth(500);
        taulukko2.setPrefHeight(500);

        TableColumn<Asiakkaat, Integer> ID = new TableColumn<>("ID");
        ID.setCellValueFactory(new PropertyValueFactory<>("asiakasID"));

        TableColumn<Asiakkaat, String> Nimi = new TableColumn<>("Nimi");
        Nimi.setCellValueFactory(new PropertyValueFactory<>("nimi"));

        TableColumn<Asiakkaat, String> Sahkoposti = new TableColumn<>("Sähköposti");
        Sahkoposti.setCellValueFactory(new PropertyValueFactory<>("sahkoposti"));

        TableColumn<Asiakkaat, String> Puhelinnumero = new TableColumn<>("Puhelinnumero");
        Puhelinnumero.setCellValueFactory(new PropertyValueFactory<>("puhelinnumero"));

        taulukko2.getColumns().addAll(ID, Nimi, Sahkoposti, Puhelinnumero);

        // Kentät syötteille
        Label otsikko = new Label("ASIAKKUUDET");
        otsikko.setTextFill(Color.DARKGREEN);

        TextField nimiTiedot = new TextField();
        nimiTiedot.setPromptText("Koko nimi");

        TextField puhTiedot = new TextField();
        puhTiedot.setPromptText("Puhelinnumero");

        TextField sapoTiedot = new TextField();
        sapoTiedot.setPromptText("Sähköpostiosoite");

        // Virhetilanteiden varalle
        Label ilmoitus1 = new Label("Kaikki kentät on täydennettävä!");
        ilmoitus1.setTextFill(Color.RED);
        ilmoitus1.setVisible(false);

        // Virhetilanteiden varalle #2
        Label ilmoitus2 = new Label("Valitse ensin poistettava asiakas!");
        ilmoitus2.setTextFill(Color.RED);
        ilmoitus2.setVisible(false);

        // Uusi asiakas -painike
        Button uusiAsiakas = new Button("Perusta uusi asiakas");
        uusiAsiakas.setStyle("-fx-border-color: darkgreen;");
        uusiAsiakas.setOnAction(e -> {
            String nimi = nimiTiedot.getText();
            String puhelin = puhTiedot.getText();
            String sahkoposti = sapoTiedot.getText();

            if (!nimi.isEmpty() && !puhelin.isEmpty() && !sahkoposti.isEmpty()) {
                try (Connection yhdista = Tietokanta.getConnection()) {
                    String sql = "INSERT INTO Asiakas (nimi, puhelin, sahkoposti) VALUES (?, ?, ?)";
                    PreparedStatement ps = yhdista.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, nimi);
                    ps.setString(2, puhelin);
                    ps.setString(3, sahkoposti);
                    ps.executeUpdate();

                    ResultSet rs = ps.getGeneratedKeys();
                    if (rs.next()) {
                        int id = rs.getInt(1);
                        asiakkaat.add(new Asiakkaat(nimi, puhelin, sahkoposti, id));
                    }
                    // tyhjennetään lomakkeen kentät
                    nimiTiedot.clear();
                    puhTiedot.clear();
                    sapoTiedot.clear();
                    ilmoitus1.setVisible(false);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    ilmoitus1.setText("Tallentaminen epäonnistui!");
                    ilmoitus1.setVisible(true);
                }
            } else {
                ilmoitus1.setText("Kaikki kentät on täydennettävä!");
                ilmoitus1.setVisible(true);
            }
        });

        // Poista asiakas -painike
        Button poistaAsiakas = new Button("Poista asiakas");
        poistaAsiakas.setStyle("-fx-border-color: darkgreen;");
        poistaAsiakas.setOnAction(e -> {
            Asiakkaat valittu = taulukko2.getSelectionModel().getSelectedItem();
            if (valittu != null) {
                try (Connection yhdista = Tietokanta.getConnection()) {
                    String sql = "DELETE FROM Asiakas WHERE asiakas_id = ?";
                    PreparedStatement ps = yhdista.prepareStatement(sql);
                    ps.setInt(1, valittu.getAsiakasID());
                    ps.executeUpdate();

                    asiakkaat.remove(valittu);
                    ilmoitus2.setVisible(false);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } else {
                ilmoitus2.setText("Valitse ensin poistettava asiakas!");
                ilmoitus2.setVisible(true);
            }
        });

        // Paluu -painike
        Button paluu = new Button("Takaisin");
        paluu.setStyle("-fx-border-color: darkgreen;");
        paluu.setOnAction(e -> ((Stage) paluu.getScene().getWindow()).close());

        // SIJOITELLAAN KOMPONENTIT
        VBox lomake = new VBox(10, otsikko, nimiTiedot, puhTiedot, sapoTiedot, ilmoitus1, ilmoitus2);
        lomake.setStyle("-fx-background-color: transparent;");

        VBox asettelu1 = new VBox(20, taulukko2);
        asettelu1.setStyle("-fx-background-color: transparent;");

        HBox asettelu2 = new HBox(20, lomake, asettelu1);
        asettelu2.setStyle("-fx-background-color: transparent;");

        VBox asettelu3 = new VBox(10, asettelu2, uusiAsiakas, poistaAsiakas, paluu);
        asettelu3.setStyle("-fx-padding: 10; -fx-background-color: transparent; -fx-border-color: darkgreen; -fx-border-width: 3px;");

        Stage nakyma = new Stage();
        nakyma.setTitle("Asiakashallinta");
        nakyma.setScene(new Scene(asettelu3, 800, 600));
        nakyma.show();
    }

    /**
     * Lukee asiakkaat tietokannasta ja päivittää listauksen asiakkaista
     */
    public static void lueAsiakkaat() {
        asiakkaat.clear();
        try (Connection yhdista = Tietokanta.getConnection()) {
            PreparedStatement ps = yhdista.prepareStatement("SELECT * FROM Asiakas");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("asiakas_id");
                String nimi = rs.getString("nimi");
                String puhelin = rs.getString("puhelin");
                String sahkoposti = rs.getString("sahkoposti");

                Asiakkaat asiakas = new Asiakkaat(nimi, puhelin, sahkoposti, id);
                asiakkaat.add(asiakas);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
