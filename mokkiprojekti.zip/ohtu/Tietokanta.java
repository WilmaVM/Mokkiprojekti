package projekti.ohtu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Tämä luokka muodostaa yhteyden tietokantaan.
 * Yhteys muodostetaan JDBC:n avulla MySQL-tietokantaan.
 */
public class Tietokanta {
    /**
     * Luo yhteyden tietokantaan nimeltä 'mokkikodit'
     * @return Connection, yhteys onnistui
     * @throws SQLException mikäli yhteys epäonnistuu
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mokkikodit", "root", "salasana");
    }
}

