package projekti.ohtu.MOKIT;

/**
 * Tämä luokka sisältää mökkien tiedot
 */

public class Mokit {

    // Oliomuuttujat
    private int mokinID;
    private String mokinOsoite;
    private double mokinHinta;
    private String mokinVarustelu;
    private int mokinKapasiteetti;

    /**
     * Luodaan uusi Mokit -olio annetuilla tiedoilla
     * @param mokinOsoite mökin osoite
     * @param mokinID mökin numero (ID)
     * @param mokinHinta hinta / yö
     * @param mokinVarustelu suihku/sauna/poreamme
     * @param mokinKapasiteetti max.henkilömäärä
     */
    public Mokit(String mokinOsoite, int mokinID, double mokinHinta, String mokinVarustelu, int mokinKapasiteetti) {
        this.mokinOsoite = mokinOsoite;
        this.mokinID = mokinID;
        this.mokinHinta = mokinHinta;
        this.mokinVarustelu = mokinVarustelu;
        this.mokinKapasiteetti = mokinKapasiteetti;
    }

    /**
     * Palauttaa mökin osoitteen
     * @return osoite
     */
    public String getMokinOsoite() {
        return mokinOsoite;
    }

    /**
     * Palauttaa mökin numeron eli ID:n
     * @return mökin ID
     */
    public int getMokinID() {
        return mokinID;
    }

    /**
     * Palauttaa mökin hinnan / yö
     * @return hinta
     */
    public double getMokinHinta() {
        return mokinHinta;
    }

    /**
     * Palauttaa mökin varustelutiedot
     * @return varustelu
     */
    public String getMokinVarustelu() {
        return mokinVarustelu;
    }

    /**
     * Palauttaa mökin max. henkilömäärä -tiedon
     * @return kapasiteetti
     */
    public int getMokinKapasiteetti() {
        return mokinKapasiteetti;
    }

}