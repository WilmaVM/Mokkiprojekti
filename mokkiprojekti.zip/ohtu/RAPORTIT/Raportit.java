package projekti.ohtu.RAPORTIT;

/**
 * Tämä luokka sisältää tiedot raporttien muodostamista varten
 */

public class Raportit {

    // Oliomuuttujat
    private double varausAika;
    private String suosituinMokki;
    private int varaustenMaara;
    private int avoimienLaskujenMaara;
    private int avoimienLaskujenSumma;
    private int maksettujenLaskujenSumma;

    /**
     * Luodaan uusi Raportit -olio annetuilla tiedoilla
     * @param varausAika keskimääräinen varauksen kesto
     * @param suosituinMokki varausasteeltaan korkein mökki
     * @param varaustenMaara varausten kokonaismäärä
     * @param avoimetLaskutMaara saatavien määrä
     * @param avoimetLaskutSumma saatavien yhteissumma
     * @param maksetutLaskutSumma saatujen yhteyssumma
     */
    public Raportit(double varausAika, String suosituinMokki, int varaustenMaara, int avoimetLaskutMaara, int avoimetLaskutSumma, int maksetutLaskutSumma) {
        this.varausAika = varausAika;
        this.suosituinMokki = suosituinMokki;
        this.varaustenMaara = varaustenMaara;
        this.avoimienLaskujenMaara = avoimetLaskutMaara;
        this.avoimienLaskujenSumma = avoimetLaskutSumma;
        this.maksettujenLaskujenSumma = maksetutLaskutSumma;
    }

    /**
     * Palauttaa keskimääräisen varausajan
     * @return varausaika
     */
    // Getterit ja setterit
    public double getVarausAika() {
        return varausAika;
    }

    /**
     * Syöttää keskimääräisen varausajan
     * @param varausAika
     */
    public void setVarausAika(double varausAika) {
        this.varausAika = varausAika;
    }

    /**
     * Palauttaa suosituimman mökin nimen
     * @return suosituin mökki
     */
    public String getSuosituinMokki() {
        return suosituinMokki;
    }

    /**
     * Syöttää suosituimman mökin nimen
     * @param suosituinMokki
     */
    public void setSuosituinMokki(String suosituinMokki) {
        this.suosituinMokki = suosituinMokki;
    }

    /**
     * Palauttaa varausten kokonaismäärän
     * @return kaikki varaukset
     */
    public int getVaraustenMaara() {
        return varaustenMaara;
    }

    /**
     * Syöttää varausten kokonaismäärän
     * @param varaustenMaara
     */
    public void setVaraustenMaara(int varaustenMaara) {
        this.varaustenMaara = varaustenMaara;
    }

    /**
     * Palauttaa avointen laskujen lukumäärän
     * @return avoimet laskut kpl
     */
    public int getAvoimienLaskujenMaara() {
        return avoimienLaskujenMaara;
    }

    /**
     * Syöttää avointen laskujen lukumäärän
     * @param avoimienLaskujenMaara
     */
    public void setAvoimienLaskujenMaara(int avoimienLaskujenMaara) {
        this.avoimienLaskujenMaara = avoimienLaskujenMaara;
    }

    /**
     * Palauttaa avointen laskujen yhteissumman
     * @return avoimet laskut yhteissumma
     */
    public int getAvoimienLaskujenSumma() {
        return avoimienLaskujenSumma;
    }

    /**
     * Syöttää avointen laskujen yhteissumman
     * @param avoimienLaskujenSumma
     */
    public void setAvoimienLaskujenSumma(int avoimienLaskujenSumma) {
        this.avoimienLaskujenSumma = avoimienLaskujenSumma;
    }

    /**
     * Palauttaa maksettujen laskujen yhteissumman
     * @return maksetut laskut yhteissumma
     */
    public int getMaksettujenLaskujenSumma() {
        return maksettujenLaskujenSumma;
    }

    /**
     * Syöttää maksettujen laskujen yhteissumman
     * @param maksettujenLaskujenSumma
     */
    public void setMaksettujenLaskujenSumma(int maksettujenLaskujenSumma) {
        this.maksettujenLaskujenSumma = maksettujenLaskujenSumma;
    }
}
