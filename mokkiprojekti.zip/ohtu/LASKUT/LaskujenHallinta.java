package projekti.ohtu.LASKUT;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import projekti.ohtu.Tietokanta;

/**
 * Tämä luokka vastaa laskujen hallitsemisesta graafisessa käyttöliittymässä.
 * Luokka hyödyntää tietokantayhteyttä laskujen muodostamiseksi ja hallinnoimiseksi.
 * Käyttöliittymä voi luokan ansiosta tarkastella, luoda, poistaa ja muokata laskuja.
 */
public class LaskujenHallinta {

    // Määritellään kentät syötteille
    private  static TextField varauksenSumma = new TextField();
    private static TextField varauksenID = new TextField();
    private static TextField asetaEP = new TextField();
    private static TextField maksupaiva = new TextField();

    private static final ObservableList<Laskut> laskut = FXCollections.observableArrayList();

    /**
     * Näyttää ikkunan, jonne Laskujen hallinta -näkymä avautuu.
     * Luo käyttöliittymälle taulukon ja muut komponentit sekä sijoittaa ne kehykseen.
     */
    public static void nayta() {
        lueLaskut();

        // Tehdään taulukko
        TableView<Laskut> taulukko4 = new TableView<>();
        taulukko4.setStyle("-fx-border-color: darkgreen;");
        taulukko4.setItems(laskut);
        taulukko4.setPrefWidth(500);
        taulukko4.setPrefHeight(500);
        taulukko4.setEditable(true);

        TableColumn<Laskut, String> Erapaiva = new TableColumn<>("Eräpäivä");
        Erapaiva.setCellValueFactory(new PropertyValueFactory<>("eraPaiva"));

        TableColumn<Laskut, String> Summa = new TableColumn<>("Summa");
        Summa.setCellValueFactory(new PropertyValueFactory<>("summa"));

        TableColumn<Laskut, Integer> ID = new TableColumn<>("ID");
        ID.setCellValueFactory(new PropertyValueFactory<>("laskunID"));

        TableColumn<Laskut, Integer> VarausID = new TableColumn<>("Varauksen ID");
        VarausID.setCellValueFactory(new PropertyValueFactory<>("varausID"));

        TableColumn<Laskut, String> Maksupaiva = new TableColumn<>("Maksupäivä");
        Maksupaiva.setCellValueFactory(new PropertyValueFactory<>("maksuPaiva"));

        taulukko4.getColumns().addAll(Erapaiva, Summa, ID, VarausID, Maksupaiva);

        // Alustetaan uuden laskun tekeminen
        Label otsikko = new Label("LASKUT");
        otsikko.setTextFill(Color.DARKGREEN);

        varauksenID.setPromptText("Varauksen ID");
        varauksenID.setOnAction(event -> {
            try {
                int varausID = Integer.parseInt(varauksenID.getText().trim());
                hinnanHakeminen(varausID);
            } catch (NumberFormatException e) {
                varauksenSumma.clear();
            }
        });

        varauksenSumma.setPromptText("Summa");
        asetaEP.setPromptText("Eräpäivä (PP.KK.VVVV)");
        maksupaiva.setPromptText("Maksupäivä (VVVV.KK.PP)");

        // Virhetilanteen varalle
        Label ilmoitus1 = new Label("Kaikki kentät on täydennettävä!");
        ilmoitus1.setTextFill(Color.RED);
        ilmoitus1.setVisible(false);

        varauksenID.textProperty().addListener((observable, oldVal, newVal) -> {
            if (!newVal.isEmpty()) {
                try {
                    int varausID = Integer.parseInt(newVal);
                    hinnanHakeminen(varausID);
                } catch (NumberFormatException e) {
                    varauksenSumma.clear();
                }
            }
        });

        // Uusi lasku -painike
        Button uusiLasku = new Button("Uusi lasku");
        uusiLasku.setStyle("-fx-border-color: darkgreen;");
        uusiLasku.setOnAction(e -> {
            String syotettyErapaiva = asetaEP.getText().trim();
            String syotettyMaksuPaiva = maksupaiva.getText().trim();
            DateTimeFormatter format1 = DateTimeFormatter.ofPattern("d.M.yyyy");
            DateTimeFormatter format2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            String asetaErapaiva = "";
            String asetaMaksupaiva = "";

            try {
                LocalDate EP = LocalDate.parse(syotettyErapaiva, format1);
                asetaErapaiva = EP.format(format2);
            } catch (DateTimeParseException e1) {
                System.out.println("Eräpäivä syötetty virheellisessä muodossa!");
            }

            if (!syotettyMaksuPaiva.isEmpty()) {
                try {
                    LocalDate MP = LocalDate.parse(syotettyMaksuPaiva, format1);
                    asetaMaksupaiva = MP.format(format2);
                } catch (DateTimeParseException e2) {
                    System.out.println("Maksupäivä syötetty virheellisessä muodossa!");
                }
            }
            String varausid = varauksenID.getText();
            String maara = varauksenSumma.getText();
            String erapaiva = asetaEP.getText();
            String maksuPaiva = maksupaiva.getText();

            if (varausid.isEmpty() || maara.isEmpty() || erapaiva.isEmpty()) {
                ilmoitus1.setVisible(true);
                return;
            }
            int varausID = Integer.parseInt(varausid);
            int summa = Integer.parseInt(varauksenSumma.getText().trim());

            // Tallennetaan lasku tietokantaan ja päivitetään tableview -näkymä
            laskunTallennus(varausID, summa, asetaErapaiva, asetaMaksupaiva);

            // Tyhjennetään kentät
            varauksenID.clear();
            varauksenSumma.clear();
            asetaEP.clear();
            ilmoitus1.setVisible(false);

        });

        // Laskun muokkaus -painike
        Button muokkaaLasku = new Button("Muokkaa laskua");
        muokkaaLasku.setStyle("-fx-border-color: darkgreen;");
        muokkaaLasku.setOnAction(e -> {
            Laskut valittuLasku = taulukko4.getSelectionModel().getSelectedItem();

            if (valittuLasku != null) {
                String maksupaivaText = maksupaiva.getText().trim();

                if (maksupaivaText != null && !maksupaivaText.isEmpty()) {
                    // Päivitetään maksupäivä tietokantaan
                    asetaMaksupaiva(valittuLasku.getLaskunID(), maksupaivaText);

                    // Päivitetään maksupäivä käyttöliittymän grafiikkaan
                    valittuLasku.setMaksuPaiva(maksupaivaText);
                    taulukko4.refresh();
                } else {
                    System.out.println("Laskua ei valittu muokattavaksi");
                }
            }
        });
        // Virheiden varalle #2
        Label ilmoitus2 = new Label("Valitse ensin poistettava lasku!");
        ilmoitus2.setTextFill(Color.RED);
        ilmoitus2.setVisible(false);

        // Laskun poisto -painike
        Button poistaLasku = new Button("Poista lasku");
        poistaLasku.setStyle("-fx-border-color: darkgreen;");
        poistaLasku.setOnAction(e -> {
            Laskut valittu = taulukko4.getSelectionModel().getSelectedItem();
            if (valittu != null) {
                try (Connection yhdista = Tietokanta.getConnection()) {
                    String sql = "DELETE FROM Lasku WHERE lasku_id = ?";
                    PreparedStatement ps = yhdista.prepareStatement(sql);
                    ps.setInt(1, valittu.getLaskunID());
                    ps.executeUpdate();

                    LaskujenHallinta.laskut.remove(valittu);
                    ilmoitus2.setVisible(false);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } else {
                ilmoitus2.setText("Valitse poistettava lasku!");
                ilmoitus2.setVisible(true);
            }
        });
        // Paluu -painike
        Button paluu = new Button("Takaisin");
        paluu.setStyle("-fx-border-color: darkgreen;");
        paluu.setOnAction(e -> ((Stage) paluu.getScene().getWindow()).close());

        // SIJOITELLAAN KOMPONENTIT
        VBox asettelu1 = new VBox(10, otsikko, varauksenID, varauksenSumma, asetaEP, maksupaiva, ilmoitus1);
        asettelu1.setStyle("-fx-background-color: transparent;");

        VBox asettelu2 = new VBox(20, taulukko4);
        asettelu2.setStyle("-fx-background-color: transparent;");

        HBox asettelu3 = new HBox(20, asettelu1, asettelu2);
        asettelu3.setStyle("-fx-background-color: transparent;");

        VBox asettelu4 = new VBox(10, asettelu3, ilmoitus2, uusiLasku, muokkaaLasku, poistaLasku, paluu);
        asettelu4.setStyle("-fx-padding: 10; -fx-background-color: transparent; -fx-border-color: darkgreen; -fx-border-width: 3px;");

        Stage nakyma = new Stage();
        nakyma.setTitle("Laskujen hallinta");
        nakyma.setScene(new Scene(asettelu4, 800, 600));
        nakyma.show();

    }

    /**
     * Tallentaa laskun tietokantaan ja päivittää taulukon
     * @param varausID varauksen tunniste
     * @param summa laskun summa (euro)
     * @param erapaiva laskun eräpäivä
     * @param maksuPaiva laskun suorituspäivä (voi olla tyhjä)
     */
    public static void laskunTallennus(int varausID, int summa, String erapaiva, String maksuPaiva) {
        String sql = "INSERT INTO Lasku (varaus_id, summa, erapaiva, maksupaiva) VALUES (?, ?, ?, ?)";

        try (Connection yhdista = Tietokanta.getConnection();
             PreparedStatement ps = yhdista.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, varausID);
            ps.setInt(2, summa);

            // Eräpäivän käsittelyyn
            if (erapaiva == null || erapaiva.trim().isEmpty()) {
                ps.setNull(3, java.sql.Types.VARCHAR);
            } else {
                ps.setString(3, erapaiva);
            }

            // Maksupäivän käsittelyyn
            if (maksuPaiva == null || maksuPaiva.trim().isEmpty()) {
                ps.setNull(4, java.sql.Types.VARCHAR);
            } else {
                ps.setString(4, maksuPaiva);
            }

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                // Noudetaan tietokannan luoma laskuID
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int laskuID = generatedKeys.getInt(1);
                        System.out.println("Onnistuneesti tietokantaan tallennettu lasku numero: " + laskuID);
                        laskut.add(new Laskut(erapaiva, varausID, laskuID, summa, ""));
                    }
                }
            } else {
                System.out.println("Laskun tallentaminen tietokantaan epäonnistui.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Hakee varauksen hinnan tietokannasta ja laskee keston perusteella kokonaissumman
     * @param varausID varauksen tunniste
     */
    public static void hinnanHakeminen(int varausID) {
        String sql = """
        SELECT m.hinta, v.aloitus_pvm, v.paattymis_pvm
        FROM Varaus v
        JOIN Mokit m ON v.mokki_id = m.mokki_id
        WHERE v.varaus_id = ?
        """;

        try (Connection yhdista = Tietokanta.getConnection();
             PreparedStatement ps = yhdista.prepareStatement(sql)) {

            ps.setInt(1, varausID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double hinta = rs.getDouble("hinta");
                Date alku = rs.getDate("aloitus_pvm");
                Date loppu = rs.getDate("paattymis_pvm");

                if (alku != null && loppu != null) {
                    long paivienVali = (loppu.toLocalDate().toEpochDay() - alku.toLocalDate().toEpochDay());

                    int yot = (int) Math.max(paivienVali, 1);
                    int summa = (int) (hinta * yot);

                    varauksenSumma.setText(String.valueOf(summa));
                } else {
                    System.out.println("Varauspäivämäärät puuttuvat!");
                    varauksenSumma.clear();
                }
            } else {
                System.out.println("Ei osumia varaustunnuksella: " + varausID);
                varauksenSumma.clear();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Asettaa maksupäivän laskulle ja päivittää sen myös tietokantaan
     * @param laskuID laskun yksilöintitieto
     * @param maksupaiva suorituspäivä
     */
    public static void asetaMaksupaiva(int laskuID, String maksupaiva) {
        if (maksupaiva == null || maksupaiva.isEmpty()) {
            System.out.println("Maksupäivä tyhjä, toiminto epäonnistui!");
            return;
        }
        String sql = "UPDATE Lasku SET maksupaiva = ? WHERE lasku_id = ?";

        try (Connection yhdista = Tietokanta.getConnection();
             PreparedStatement ps = yhdista.prepareStatement(sql)) {

            ps.setString(1, maksupaiva);
            ps.setInt(2, laskuID);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Maksupäivä päivitettiin onnistuneesti laskulle: " + laskuID);
            } else {
                System.out.println("Maksupäivää lisääminen epäonnistui.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lukee laskuja tietokannasta ja päivittää TableView -näkymää
     */
    public static void lueLaskut() {
        laskut.clear();
        try (Connection yhdista = Tietokanta.getConnection()) {
            PreparedStatement ps = yhdista.prepareStatement("SELECT * FROM Lasku");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int laskunID = rs.getInt("lasku_id");
                int varausID = rs.getInt("varaus_id");
                int summa = rs.getInt("summa");

                // muutetaan format
                String eraPaiva = "";
                Date sqlEraPaiva = rs.getDate("erapaiva");
                if (sqlEraPaiva != null) {
                    eraPaiva = new SimpleDateFormat("dd.MM.yyyy").format(sqlEraPaiva);
                }
                String maksuPaiva = "";
                Date sqlMaksuPaiva = rs.getDate("maksupaiva");
                if (sqlMaksuPaiva != null) {
                    maksuPaiva = new SimpleDateFormat("dd.MM.yyyy").format(sqlMaksuPaiva);
                }

                Laskut lasku = new Laskut(eraPaiva, varausID, laskunID, summa, maksuPaiva);
                laskut.add(lasku);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

