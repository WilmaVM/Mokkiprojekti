package projekti.ohtu;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;
import projekti.ohtu.ASIAKKAAT.Asiakashallinta;
import projekti.ohtu.LASKUT.LaskujenHallinta;
import projekti.ohtu.MOKIT.MokkienHallinta;
import projekti.ohtu.RAPORTIT.RaportitUI;
import projekti.ohtu.VARAUKSET.VaraustenHallinta;

/**
 * Pääohjelma, joka käynnistää graafisen käyttöliittymän.
 * Mahdollistaa ohjelman osien käyttämisen ja siirtymän toiminnallisuudesta toiseen.
 * Pääohjelma sisältää painikkeita sekä taustakuvan.
 */

public class Paaohjelma extends Application {
    /**
     * Luodaan komponentit ja asetetaan ne näkymään
     * @param primaryStage pääikkuna
     */

    @Override
    public void start(Stage primaryStage) {

        Label otsikko = new Label("Tervetuloa varausjärjestelmään!");
        otsikko.setTextFill(Color.DARKGREEN);
        otsikko.setFont(Font.font("Times New Roman", FontPosture.ITALIC, 25));
        otsikko.setStyle("-fx-font-weight: bold;");

        // Mökkien hallintaan -painike
        Button mokkienHallintaan = new Button ("Mökkien hallinta");
        mokkienHallintaan.setOnAction(e ->
                MokkienHallinta.nayta());

        // Asiakashallintaan -painike
        Button asiakasHallintaan = new Button("Asiakashallinta");
        asiakasHallintaan.setOnAction(e ->
                Asiakashallinta.nayta());

        // Varausten hallintaan -painike
        Button varaustenHallintaan = new Button("Varausten hallinta");
        varaustenHallintaan.setOnAction(e ->
                VaraustenHallinta.nayta());

        // Laskujen hallintaan -painike
        Button laskujenHallintaan = new Button("Laskujen hallinta");
        laskujenHallintaan.setOnAction(e ->
                LaskujenHallinta.nayta());

        // Raportti näkymään -painike
        Button raportteihin = new Button("Raportit");
        raportteihin.setOnAction(e ->
                RaportitUI.nayta());

        // Taustakuva - SIJOITA SEURAAVALLE RIVILLE OMA TIEDOSTOPOLKUSI KOSKIEN KUVAA
        Image kuva1 = new Image("file:/Users/Kayttaja/Desktop/Kuva1.jpg");
        ImageView metsa = new ImageView(kuva1);
        metsa.setFitWidth(800);
        metsa.setFitHeight(600);
        metsa.setPreserveRatio(false);

        // SIJOITETAAN KOMPONENTIT
        VBox keskella = new VBox(20, otsikko, mokkienHallintaan, asiakasHallintaan,varaustenHallintaan, laskujenHallintaan, raportteihin);
        keskella.setStyle("-fx-background-color: transparent;");
        keskella.setAlignment(Pos.CENTER);

        StackPane kokonaisuus = new StackPane();
        kokonaisuus.getChildren().addAll(metsa, keskella);
        StackPane.setAlignment(keskella, Pos.CENTER);

        Scene kehys = new Scene(kokonaisuus, 800, 600);
        metsa.fitWidthProperty().bind(kehys.widthProperty());
        metsa.fitHeightProperty().bind(kehys.heightProperty());
        primaryStage.setTitle("Mökkikodit");
        primaryStage.setScene(kehys);
        primaryStage.show();
    }

    /**
     * Ohjelman ajamista varten
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }
}