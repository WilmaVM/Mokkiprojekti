package projekti.ohtu.VARAUKSET;

import javafx.scene.paint.Color;
import javafx.stage.Stage;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import projekti.ohtu.ASIAKKAAT.Asiakkaat;
import projekti.ohtu.MOKIT.Mokit;
import projekti.ohtu.MOKIT.MokkienHallinta;
import projekti.ohtu.Tietokanta;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Tämä luokka vastaa varausten näyttämisestä ja käsittelystä graafisessa käyttöliittymässä.
 * Luokka mahdollistaa varausten tarkastelun, tekemisen sekä poiston.
 * Luokka mahdollistaa myös uusien asiakkaiden tallentamisen tietokantaan ja sitä kautta asiakashallinta -näkymään.
 * Luokka hyödyntää tietokantayhteyttä tietojen hallinnoimiseksi myös useiden taulujen välillä.
 */

public class VaraustenHallinta {

    /**
     * Lista varauksista
     */
    private static final ObservableList<Varaus> varaukset = FXCollections.observableArrayList();
    /**
     * Käytetyt varaustunnisteet
     */
    private static final Set<Integer> kaytetytIDt = new HashSet<>();
    /**
     * Satunnaisten varaustunnusten luomiseksi
     */
    private static final Random satunnainen = new Random();
    /**
     * Lista asiakkaista
     */
    private static final ObservableList<Asiakkaat> asiakkaat = FXCollections.observableArrayList();
    /**
     * Mökkivalinnan tekemiseksi ComboBox
     */
    private static ComboBox<Mokit> mokkiValinnat = new ComboBox<>(MokkienHallinta.getMokit());

    /**
     * Näyttää ikkunan, jonne varausten hallinta -näkymä avautuu.
     * Luo käyttöliittymälle komponentit ja sijoittaa ne kehykseen
     */
    public static void nayta() {
        lueVaraukset();
        lueAsiakkaat();

        // Tehdään taulukko
        TableView<Varaus> taulukko3 = new TableView<>();
        taulukko3.setStyle("-fx-border-color: darkgreen;");
        taulukko3.setItems(varaukset);
        taulukko3.setPrefWidth(500);
        taulukko3.setPrefHeight(500);

        TableColumn<Varaus, Integer> ID = new TableColumn<>("Varaus ID");
        ID.setCellValueFactory(new PropertyValueFactory<>("varausID"));

        TableColumn<Varaus, LocalDate> Alkupv = new TableColumn<>("Alkupäivä");
        Alkupv.setCellValueFactory(new PropertyValueFactory<>("varausAlkupaiva"));

        TableColumn<Varaus, LocalDate> Loppupv = new TableColumn<>("Loppupäivä");
        Loppupv.setCellValueFactory(new PropertyValueFactory<>("varausLoppupaiva"));

        TableColumn<Varaus, String> Kesto = new TableColumn<>("Kesto");
        Kesto.setCellValueFactory(new PropertyValueFactory<>("varauksenKesto"));

        TableColumn<Varaus, String> VaraajaStaff = new TableColumn<>("Varaaja");
        VaraajaStaff.setCellValueFactory(new PropertyValueFactory<>("varaajaHenkilokunnasta"));

        taulukko3.getColumns().addAll(ID, Alkupv, Loppupv, Kesto, VaraajaStaff);

        // Otsikoidaan näkymää
        Label haku = new Label("Etsi olemassa olevia asiakkaita");
        haku.setTextFill(Color.DARKGREEN);

        Label perustetaan = new Label("Perusta uusi asiakas");
        perustetaan.setTextFill(Color.DARKGREEN);

        Label varauksenTeko = new Label("VARAUKSET");
        varauksenTeko.setTextFill(Color.DARKGREEN);

        // Päivämäärävalinnat varaukselle
        Label ajankohta = new Label("Ajankohta");
        ajankohta.setTextFill(Color.DARKGREEN);

        DatePicker varauksenAlku = new DatePicker();
        varauksenAlku.setPromptText("Varauksen alkupäivä");
        varauksenAlku.setStyle("-fx-font-color: darkgreen;");

        // Varauksen alkupäivä ei voi olla aikaisempi, kuin kuluva päivä
        varauksenAlku.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });

        DatePicker varauksenLoppu = new DatePicker();
        varauksenLoppu.setPromptText("Varauksen päättymispäivä");
        varauksenLoppu.setStyle("-fx-font-color: darkgreen;");

        // Kuuntelijat, jotta tarjoaa oikeat mökit varattavaksi päivämäärien perusteella
        varauksenAlku.valueProperty().addListener((obs, oldVal, newVal) -> {
            mokkiValinnat.setButtonCell(mokkiValinnat.getCellFactory().call(null));
            mokkiValinnat.setItems(FXCollections.observableArrayList(MokkienHallinta.getMokit()));
        });

        varauksenLoppu.valueProperty().addListener((obs, oldVal, newVal) -> {
            mokkiValinnat.setButtonCell(mokkiValinnat.getCellFactory().call(null));
            mokkiValinnat.setItems(FXCollections.observableArrayList(MokkienHallinta.getMokit()));
        });


        // Varauksen loppupäivä ei voi olla aikaisempi, kuin varauksen alkupäivä
        varauksenAlku.valueProperty().addListener((obs, oldVal, newVal) -> {
            varauksenLoppu.setDayCellFactory(picker -> new DateCell() {
                @Override
                public void updateItem(LocalDate date, boolean empty) {
                    super.updateItem(date, empty);
                    setDisable(empty || date.isBefore(newVal));
                }
            });
        });

        // Henkilön nimi, joka tekee varauksen
        TextField varaajaStaff = new TextField();
        varaajaStaff.setPromptText("Varaajan nimi (staff)");
        varaajaStaff.setStyle("-fx-font-color: darkgreen;");

        // Haetaan olemassa olevia asiakkaita tietokannasta
        TextField haetaanAsiakas = new TextField();
        haetaanAsiakas.setPromptText("Hae asiakkuutta nimellä");
        haetaanAsiakas.setStyle("-fx-font-color: darkgreen;");
        ListView<Asiakkaat> hakutulokset = new ListView<>();
        hakutulokset.setMaxHeight(300);

        haetaanAsiakas.textProperty().addListener((observable, oldVal, newVal) -> {
            if (newVal.isEmpty()) {
                hakutulokset.setItems(FXCollections.observableArrayList());
                return;
            }

            List<Asiakkaat> tulokset = new ArrayList<>();

            try (Connection yhdista = Tietokanta.getConnection()) {
                String sql = "SELECT * FROM Asiakas WHERE LOWER(nimi) LIKE ?";
                PreparedStatement pr = yhdista.prepareStatement(sql);
                pr.setString(1, "%" + newVal.toLowerCase() + "%");
                ResultSet rs = pr.executeQuery();

                while (rs.next()) {
                    int id = rs.getInt("asiakas_id");
                    String nimi = rs.getString("nimi");
                    String puh = rs.getString("puhelin");
                    String sposti = rs.getString("sahkoposti");
                    tulokset.add(new Asiakkaat(nimi, puh, sposti, id));
                }

                hakutulokset.setItems(FXCollections.observableArrayList(tulokset));
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        });

        // Kentät, kun luodaan kokonaan uusi asiakas
        TextField asiakkaanNimi = new TextField();
        asiakkaanNimi.setPromptText("Asiakkaan nimi");
        asiakkaanNimi.setStyle("-fx-font-color: darkgreen;");

        TextField asiakkaanPuh = new TextField();
        asiakkaanPuh.setPromptText("Asiakkaan puhelinnumero");
        asiakkaanPuh.setStyle("-fx-font-color: darkgreen;");

        TextField asiakkaanSapo = new TextField();
        asiakkaanSapo.setPromptText("Asiakkaan sähköpostiosoite");
        asiakkaanSapo.setStyle("-fx-font-color: darkgreen;");

        hakutulokset.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                asiakkaanNimi.setText(newVal.getNimi());
                asiakkaanPuh.setText(newVal.getPuhelinnumero());
                asiakkaanSapo.setText(newVal.getSahkoposti());
            }
        });
        // Kanava varauksen tekemiseksi
        Label kanavaKysymys = new Label("Kanava, josta varaus tehtiin");
        kanavaKysymys.setTextFill(Color.DARKGREEN);

        ToggleGroup kanava = new ToggleGroup();
        RadioButton puhelin = new RadioButton("Puhelin");
        RadioButton sahkoposti = new RadioButton("Sähköposti");

        puhelin.setToggleGroup(kanava);
        sahkoposti.setToggleGroup(kanava);

        HBox asettelu1 = new HBox(10, puhelin, sahkoposti);
        asettelu1.setStyle("-fx-background-color: transparent;");

        // Mökin valitsemiseksi varaukselle
        Label otsikko = new Label("Valitse varattava mökki");
        otsikko.setTextFill(Color.DARKGREEN);

        mokkiValinnat.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Mokit item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setTextFill(Color.DARKGREEN);
                } else {
                    setText(item.getMokinOsoite());

                    LocalDate alku = varauksenAlku.getValue();
                    LocalDate loppu = varauksenLoppu.getValue();

                    if (alku != null && loppu != null && MokinTila(item.getMokinID(), alku, loppu)) {
                        setTextFill(Color.RED);
                    } else {
                        setTextFill(Color.DARKGREEN);
                    }
                }
            }
        });
        mokkiValinnat.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Mokit item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getMokinOsoite());
                }
            }
        });

        // Virhetilanteiden varalle
        Label ilmoitus1 = new Label("Kaikki kentät on täydennettävä!");
        ilmoitus1.setTextFill(Color.RED);
        ilmoitus1.setVisible(false);

        // Virhetilanteiden varalle #2
        Label ilmoitus2 = new Label("Varauksen alkupäivä ei voi olla myöhäisempi kuin päättymispäivä!");
        ilmoitus2.setTextFill(Color.RED);
        ilmoitus2.setVisible(false);

        // Virhetilanteiden varalle #3
        Label ilmoitus3 = new Label("Valitse ensin poistettava varaus!");
        ilmoitus3.setTextFill(Color.RED);
        ilmoitus3.setVisible(false);

        // Uusi varaus -painike
        Button uusiVaraus = new Button("Tee uusi varaus");
        uusiVaraus.setStyle("-fx-border-color: darkgreen;");
        uusiVaraus.setOnAction(e -> {
            LocalDate alku = varauksenAlku.getValue();
            LocalDate loppu = varauksenLoppu.getValue();
            String varaaja = varaajaStaff.getText();
            Mokit mokki = mokkiValinnat.getValue();

            if (alku == null || loppu == null || varaaja.isEmpty() || mokki == null) {
                ilmoitus1.setVisible(true);
                return;
            }
            // Tallennetaan varaus tietokantaan
            try (Connection yhdista = Tietokanta.getConnection()) {
                String sql = "SELECT * FROM Varaus WHERE mokki_id = ? AND aloitus_pvm < ? AND paattymis_pvm > ?";

                PreparedStatement ps = yhdista.prepareStatement(sql);
                ps.setInt(1, mokki.getMokinID());
                ps.setDate(2, Date.valueOf(loppu));
                ps.setDate(3, Date.valueOf(alku));

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    ilmoitus2.setVisible(true);
                    return;
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            int asiakasId = -1;
            String nimi = asiakkaanNimi.getText();
            String puh = asiakkaanPuh.getText();
            String sapo = asiakkaanSapo.getText();

            Asiakkaat valittuAsiakas = hakutulokset.getSelectionModel().getSelectedItem();
            if (valittuAsiakas != null) {
                asiakasId = valittuAsiakas.getAsiakasID();
            } else {
            }

            // Asiakkaan hakeminen tietokannasta
            try (Connection yhdista = Tietokanta.getConnection()) {
                String sqlHaku = "SELECT asiakas_id FROM Asiakas WHERE nimi = ?";
                PreparedStatement stmt = yhdista.prepareStatement(sqlHaku);
                stmt.setString(1, nimi);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    asiakasId = rs.getInt("asiakas_id");
                } else {
                    // Jos asiakasta ei löydy, luodaan uusi
                    String sqlLuodaan = "INSERT INTO Asiakas (nimi, puhelin, sahkoposti) VALUES (?, ?, ?)";
                    PreparedStatement sisallyta = yhdista.prepareStatement(sqlLuodaan, Statement.RETURN_GENERATED_KEYS);
                    sisallyta.setString(1, nimi);
                    sisallyta.setString(2, puh);
                    sisallyta.setString(3, sapo);
                    sisallyta.executeUpdate();

                    ResultSet asiakastunnukset = sisallyta.getGeneratedKeys();
                    if (asiakastunnukset.next()) {
                        asiakasId = asiakastunnukset.getInt(1);
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            long kestonLaskeminen = ChronoUnit.DAYS.between(alku, loppu);
            String kesto = kestonLaskeminen + " päivää";
            int varausId = varaustunnuksenLuominen();

            // Uuden varauksen luominen
            try (Connection yhdista = Tietokanta.getConnection()) {
                String sql = "INSERT INTO Varaus (varaus_id, asiakas_id, mokki_id, aloitus_pvm, paattymis_pvm, kesto, varaajan_nimi) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = yhdista.prepareStatement(sql);

                ps.setInt(1, varausId);
                ps.setInt(2, asiakasId);
                ps.setInt(3, mokki.getMokinID());
                ps.setDate(4, Date.valueOf(alku));
                ps.setDate(5, Date.valueOf(loppu));
                ps.setString(6, kesto);
                ps.setString(7, varaaja);

                ps.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            valittuAsiakas = hakutulokset.getSelectionModel().getSelectedItem();
            if (valittuAsiakas != null) {
                asiakasId = valittuAsiakas.getAsiakasID();
            }
            varaukset.add(new Varaus(alku, loppu, kesto, varausId, varaaja, mokki));

            // Tyhjennetään kentät
            varauksenAlku.setValue(null);
            varauksenLoppu.setValue(null);
            mokkiValinnat.setValue(null);
            varaajaStaff.clear();
            asiakkaanNimi.clear();
            asiakkaanPuh.clear();
            asiakkaanSapo.clear();
            haetaanAsiakas.clear();
            kanava.selectToggle(null);
            ilmoitus1.setVisible(false);
            ilmoitus2.setVisible(false);
            ilmoitus3.setVisible(false);
        });

        // Poista varaus -painike
        Button poistaVaraus = new Button("Poista varaus");
        poistaVaraus.setStyle("-fx-border-color: darkgreen;");
        poistaVaraus.setOnAction(e -> {
            Varaus valittu = taulukko3.getSelectionModel().getSelectedItem();
            if (valittu != null) {
                try (Connection yhdista = Tietokanta.getConnection()) {
                    String sql = "DELETE FROM Varaus WHERE varaus_id = ?";
                    PreparedStatement ps = yhdista.prepareStatement(sql);
                    ps.setInt(1, valittu.getVarausID());
                    ps.executeUpdate();

                    varaukset.remove(valittu);
                    ilmoitus3.setVisible(false);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } else {
                ilmoitus3.setVisible(true);
            }
        });

        // Paluu -painike
        Button paluu = new Button("Takaisin");
        paluu.setOnAction(e -> ((Stage) paluu.getScene().getWindow()).close());
        paluu.setStyle("-fx-border-color: darkgreen;");

        // SIJOITELLAAN KOMPONENTIT
        VBox asettelu2 = new VBox(10, haku, haetaanAsiakas, hakutulokset);
        asettelu2.setStyle("-fx-background-color: transparent;");

        VBox asettelu3 = new VBox(10, perustetaan, asiakkaanNimi, asiakkaanPuh, asiakkaanSapo);
        asettelu3.setStyle("-fx-background-color: transparent;");

        VBox asettelu4 = new VBox(10, varauksenTeko, ajankohta, varauksenAlku, varauksenLoppu, otsikko, mokkiValinnat, kanavaKysymys, asettelu1, asettelu2, asettelu3, varaajaStaff, ilmoitus1, ilmoitus3, uusiVaraus, poistaVaraus);
        asettelu4.setStyle("-fx-background-color: transparent;");

        VBox asettelu5 = new VBox(10, taulukko3);
        asettelu5.setStyle("-fx-background-color: transparent;");

        HBox asettelu6 = new HBox(20, asettelu4, asettelu5);
        asettelu6.setStyle("-fx-background-color: transparent;");

        VBox asettelu7 = new VBox(10, asettelu6, paluu);
        asettelu7.setStyle("-fx-padding: 10; -fx-border-width: 3px; -fx-background-color: transparent; -fx-border-color: darkgreen;");

        Stage nakyma = new Stage();
        nakyma.setTitle("Varausten hallinta");
        nakyma.setScene(new Scene(asettelu7, 1000, 800));
        nakyma.show();
    }

    /**
     * Luo jokaisesta varauksesta uniikin, satunnaisen 8-numeroisen varaustunnisteen eli ID:n
     * Varmistaa, ettei ko. tunniste ole ollut aikaisemmin käytössä.
     * @return varausID
     */
    private static int varaustunnuksenLuominen() {
        int id;
        do {
            id = 10000000 + satunnainen.nextInt(90000000);
        } while (kaytetytIDt.contains(id));
        kaytetytIDt.add(id);
        return id;
    }

    /**
     * Lukee varaukset tietokannasta ja päivittää listausta varauksista
     * Liittää varaukset mökkivalintaan.
     */
    public static void lueVaraukset() {
        varaukset.clear();
        try (Connection yhdista = Tietokanta.getConnection()) {
            PreparedStatement ps = yhdista.prepareStatement("SELECT * FROM Varaus");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("varaus_id");
                LocalDate alku = rs.getDate("aloitus_pvm").toLocalDate();
                LocalDate loppu = rs.getDate("paattymis_pvm").toLocalDate();
                String varaaja = rs.getString("varaajan_nimi");
                int mokkiID = rs.getInt("mokki_id");

                // Etsitään mökki listasta ID:n perusteella
                Mokit mokki = mokkiValinnat.getItems().stream()
                        .filter(m -> m.getMokinID() == mokkiID)
                        .findFirst()
                        .orElse(null);

                long kesto = ChronoUnit.DAYS.between(alku, loppu);
                varaukset.add(new Varaus(alku, loppu, kesto + " päivää", id, varaaja, mokki));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lukee asiakkaat tietokannasta ja päivittää listausta asiakkaista.
     */
    public static void lueAsiakkaat() {
        asiakkaat.clear();
        try (Connection yhdista = Tietokanta.getConnection()) {
                PreparedStatement ps = yhdista.prepareStatement("SELECT * FROM Asiakas");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    int asiakasId = rs.getInt("asiakas_id");
                    String nimi = rs.getString("nimi");
                    String puh = rs.getString("puhelin");
                    String sapo = rs.getString("sahkoposti");
                    asiakkaat.add(new Asiakkaat(nimi, puh, sapo, asiakasId));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    /**
     * Varmistaa, että mökki ei ole varattuna valitulla aikavälillä
     * @param mokkiID mökin numero
     * @param alku varauksen aloituspäivämäärä
     * @param loppu varauksen lopetuspäivämäärä
     * @return 'true', mikäli mökki varattuna ko. ajankohtana, muutoin 'false'
     */
    private static boolean MokinTila(int mokkiID, LocalDate alku, LocalDate loppu) {
        return varaukset.stream().anyMatch(varaus ->
                varaus.getMokki().getMokinID() == mokkiID &&
                        !(varaus.getVarausLoppupaiva().isBefore(alku) || varaus.getVarausAlkupaiva().isAfter(loppu))
        );
    }
}

