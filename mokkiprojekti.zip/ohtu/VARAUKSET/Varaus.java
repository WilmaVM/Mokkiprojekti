package projekti.ohtu.VARAUKSET;

import projekti.ohtu.MOKIT.Mokit;

import java.time.LocalDate;

/**
 * Tämä luokka sisältää varausten tiedot
 */
public class Varaus {

    private LocalDate varausAlkupaiva;
    private LocalDate varausLoppupaiva;
    private String varauksenKesto;
    private int varausID;
    private String varaajaHenkilokunnasta;
    private Mokit mokki;

    /**
     * Luodaan uusi Varaus -olio annetuilla tiedoilla
     * @param varausAlkupaiva varauksen alku
     * @param varausLoppupaiva varauksen loppu
     * @param varauksenKesto varauksen kesto
     * @param varausID varauksen tunniste eli ID
     * @param varaajaHenkilokunnasta varaajan nimi (henkilökuntaa)
     * @param mokki varattava mökki
     */
    public Varaus(LocalDate varausAlkupaiva, LocalDate varausLoppupaiva,
                     String varauksenKesto, int varausID, String varaajaHenkilokunnasta, Mokit mokki) {
        this.varausAlkupaiva = varausAlkupaiva;
        this.varausLoppupaiva = varausLoppupaiva;
        this.varauksenKesto = varauksenKesto;
        this.varausID = varausID;
        this.varaajaHenkilokunnasta = varaajaHenkilokunnasta;
        this.mokki = mokki;
    }

    /**
     * Palauttaa varauksen aloituspäivämäärän
     * @return aloituspäivämäärä
     */
    public LocalDate getVarausAlkupaiva() {
        return varausAlkupaiva;
    }

    /**
     * Palauttaa varauksen päättymispäivämäärän
     * @return varauksen päättymispäivämäärä
     */
    public LocalDate getVarausLoppupaiva() {
        return varausLoppupaiva;
    }

    /**
     * Palauttaa varauksen keston (yöt)
     * @return varauksen kesto
     */
    public String getVarauksenKesto() {
        return varauksenKesto;
    }

    /**
     * Palauttaa varauksen tunnisteen eli ID:n
     * @return varaus ID
     */
    public int getVarausID() {
        return varausID;
    }

    /**
     * Palauttaa varaajan nimen henkilökunnasta
     * @return varaaja
     */
    public String getVaraajaHenkilokunnasta() {
        return varaajaHenkilokunnasta;
    }

    /**
     * Palauttaa varattavan mökin
     * @return varattava mökki
     */
    public Mokit getMokki() {
        return mokki;
    }
}
